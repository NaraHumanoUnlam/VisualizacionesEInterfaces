let tramite = document.getElementById('seleccionar-tramite');
let subtramite = document.getElementById('seleccionar-subtramite');
let botonesTramites = document.querySelectorAll('#btn-tramite');
let botonesSubTramites = document.querySelectorAll('#btn-subtramite');
const btnRight = document.getElementById('btn-right-tramite');
const btnLeft = document.getElementById('btn-left-tramite');
const elementos = document.querySelectorAll('#elemento');
const btnRightSub = document.getElementById('btn-right-subtramite');
const btnLeftsub = document.getElementById('btn-left-subtramite');
const elementossub = document.querySelectorAll('#subElemento');


botonesTramites[1].classList.add('bg-lime-700');
botonesTramites.forEach(element => {
    element.addEventListener('click', () => {
        element.classList.add('bg-lime-700')
        if (botonesTramites[0] == element) {
            botonesTramites[1].classList.remove('bg-lime-700')
            botonesTramites[2].classList.remove('bg-lime-700')
        }
        if (botonesTramites[1] == element) {
            botonesTramites[0].classList.remove('bg-lime-700')
            botonesTramites[2].classList.remove('bg-lime-700')
        }
        if (botonesTramites[2] == element) {
            botonesTramites[1].classList.remove('bg-lime-700')
            botonesTramites[0].classList.remove('bg-lime-700')
        }
    })
})
botonesSubTramites[1].classList.add('bg-lime-700');
botonesSubTramites.forEach(element => {
    element.addEventListener('click', () => {
        element.classList.add('bg-lime-700')
        if (botonesSubTramites[0] == element) {
            botonesSubTramites[1].classList.remove('bg-lime-700')
            botonesSubTramites[2].classList.remove('bg-lime-700')
        }
        if (botonesSubTramites[1] == element) {
            botonesSubTramites[0].classList.remove('bg-lime-700')
            botonesSubTramites[2].classList.remove('bg-lime-700')
        }
        if (botonesSubTramites[2] == element) {
            botonesSubTramites[1].classList.remove('bg-lime-700')
            botonesSubTramites[0].classList.remove('bg-lime-700')
        }
    })
})

let currentIndex = 0;
let i = 0;

btnRight.addEventListener('click', () => {
    if (currentIndex < elementos.length - 1) {
        elementos[currentIndex].classList.add('hidden');
        currentIndex++;
        elementos[currentIndex].classList.remove('hidden');
    }
});

btnLeft.addEventListener('click', () => {
    if (currentIndex > 0) {
        elementos[currentIndex].classList.add('hidden');
        currentIndex--;
        elementos[currentIndex].classList.remove('hidden');
    }
});

btnRightSub.addEventListener('click', () => {
    if (i < elementossub.length - 1) {
        elementossub[i].classList.add('hidden');
        i++;
        elementossub[i].classList.remove('hidden');
    }
});

btnLeftsub.addEventListener('click', () => {
    if (i > 0) {
        elementossub[i].classList.add('hidden');
        i--;
        elementossub[i].classList.remove('hidden');
    }
});

function mostrarOtro() {
    tramite.classList.add('hidden');
    subtramite.classList.remove('hidden');
}
