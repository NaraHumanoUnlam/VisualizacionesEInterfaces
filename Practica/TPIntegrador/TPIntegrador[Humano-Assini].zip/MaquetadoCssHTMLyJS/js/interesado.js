let botonesTitular = document.querySelectorAll('#btn-titular');
botonesTitular[0].classList.add('bg-lime-700');
botonesTitular.forEach(element => {
    element.addEventListener('click', () => {
        element.classList.add('bg-lime-700')
        if (botonesTitular[0] == element) {
            botonesTitular[1].classList.remove('bg-lime-700')
            botonesTitular[2].classList.remove('bg-lime-700')
        }
        if (botonesTitular[1] == element) {
            botonesTitular[0].classList.remove('bg-lime-700')
            botonesTitular[2].classList.remove('bg-lime-700')
        }
        if (botonesTitular[2] == element) {
            botonesTitular[1].classList.remove('bg-lime-700')
            botonesTitular[0].classList.remove('bg-lime-700')
        }
    })
})