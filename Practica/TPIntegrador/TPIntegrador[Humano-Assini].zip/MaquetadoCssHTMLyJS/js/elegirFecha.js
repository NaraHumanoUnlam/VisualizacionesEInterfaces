const fechaElementos = document.querySelectorAll('.fecha');

let fechaSeleccionada = false;

fechaElementos.forEach((elemento) => {
  elemento.addEventListener('click', () => {
    fechaElementos.forEach((el) => {
      el.classList.remove('bg-sky-400');
      el.classList.remove('text-white');
      const textoHijo = el.firstElementChild;
      if (textoHijo) {
        textoHijo.classList.remove('text-white');
      }
    });


    elemento.classList.add('bg-sky-400');
    const textoHijoClickeado = elemento.firstElementChild;
    if (textoHijoClickeado) {
      textoHijoClickeado.classList.add('text-white');
    }

    fechaSeleccionada = true;
  });
});

function validarDatos() {
  if (fechaSeleccionada) {
    window.location.href = "seleccionarHorario.html";
  } else {
    Swal.fire({
      icon: 'error',
      title: 'Formulario Incompleto',
      text: 'Selecciona una fecha antes de continuar.',
      showCloseButton: true,
      confirmButtonColor: '#348214',
      confirmButtonText: 'Continuar',
      cancelButtonText: '<i class="fa fa-thumbs-down"></i>'
    })
  }
}