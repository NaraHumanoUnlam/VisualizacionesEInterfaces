const horariosVisibles = document.querySelectorAll('.horario:not(.hidden)');
        const horariosOcultos = document.querySelectorAll('.horario.hidden');
        let horarioSeleccionado = null;

        function toggleVisibilidadHorarios() {
        horariosVisibles.forEach((horario) => {
            horario.classList.toggle('hidden');
        });

        horariosOcultos.forEach((horario) => {
            horario.classList.toggle('hidden');
        });
        }

        function cambiarColorFondo() {
            if (horarioSeleccionado !== null) {
                horarioSeleccionado.classList.remove('bg-sky-400');
                horarioSeleccionado.classList.add('bg-white');
            }

            if (horarioSeleccionado !== this) {
                this.classList.remove('bg-white');
                this.classList.add('bg-sky-400');
                horarioSeleccionado = this;
            } else {
                horarioSeleccionado = null;
            }
            }
        const elementosHorario = document.querySelectorAll('.horario');
        elementosHorario.forEach((elemento) => {
        elemento.addEventListener('click', cambiarColorFondo);
        });

        const botonVerHorarios = document.getElementById('verHorarios');
        botonVerHorarios.addEventListener('click', toggleVisibilidadHorarios);

        function validarDatos() {
        if (horarioSeleccionado !== null) {
            Swal.fire({
            icon: 'success',
            title: 'Turno Confirmado',
            text: 'Su turno fue confirmado. Le llegará un correo electrónico con los detalles del mismo.',
            showCloseButton: false,
            confirmButtonColor: '#348214',
            confirmButtonText: 'Continuar',
            cancelButtonText: '<i class="fa fa-thumbs-down"></i>'
            }).then(function() {
            window.location.href = "home.html";
            });
        } else {
            Swal.fire({
            icon: 'error',
            title: 'Formulario Incompleto',
            text: 'Selecciona un horario antes de continuar.',
            showCloseButton: true,
            confirmButtonColor: '#348214',
            confirmButtonText: 'Aceptar',
            cancelButtonText: '<i class="fa fa-thumbs-down"></i>'
            });
        }
        }