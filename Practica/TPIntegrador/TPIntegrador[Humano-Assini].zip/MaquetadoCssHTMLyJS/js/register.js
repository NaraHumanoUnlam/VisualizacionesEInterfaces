let termino = document.getElementById('acepta-terminos');
let aceptar = document.getElementById('btn-aceptar');


aceptar.addEventListener('click', () => {
    console.log(termino.checked);
    if (!termino.checked) {
        Swal.fire({
            icon: 'error',
            title: 'Aceptar términos y condiciones',
            showCloseButton: true,
            confirmButtonColor: '#348214',
            confirmButtonText: 'Confirmar',
            cancelButtonText: '<i class="fa fa-thumbs-down"></i>'
        })
    } else {
        window.location.href = 'login.html';
    }
})