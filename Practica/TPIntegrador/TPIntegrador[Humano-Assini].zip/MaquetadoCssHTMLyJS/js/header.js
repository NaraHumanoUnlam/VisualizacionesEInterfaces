document.addEventListener("DOMContentLoaded", function () {
    var menuToggle = document.getElementById("menu-toggle");
    var menuUsuarioToggle = document.getElementById("menu-usuario-toggle");
    var menuNormal = document.getElementById("menu-normal");
    var menuUsuario = document.getElementById("menu-usuario");

    menuToggle.addEventListener("click", function () {
      menuNormal.classList.toggle("hidden");
    });

    menuUsuarioToggle.addEventListener("click", function () {
      menuUsuario.classList.toggle("hidden");
    });
  });