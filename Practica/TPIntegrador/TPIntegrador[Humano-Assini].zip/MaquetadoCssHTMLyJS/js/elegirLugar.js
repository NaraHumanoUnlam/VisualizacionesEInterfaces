const provinciaSelect = document.getElementById("provincia");
        const localidadSelect = document.getElementById("localidad");
        const sedesSelect = document.getElementById("sedes");
      
        const datosProvincias = {
          BuenosAires: {
            localidades: ["Lomas de Zamora", "Casanova"],
            sedes: ["Sede 1"]
          },
          Cordoba: {
            localidades: ["Arroyito", "Villa Carlos Paz"],
            sedes: ["Sede 2"]
          },
          Corrientes: {
            localidades: ["Goya", "Ituzaingo"],
            sedes: ["Sede 3"]
          },
          EntreRios: {
            localidades: ["Crespo", "Caseros"],
            sedes: ["Sede 4"]
          },
          Formosa: {
            localidades: ["Formosa Capital", "Ingeniero Juarez"],
            sedes: ["Sede 5"]
          }
        };
      
        provinciaSelect.addEventListener("change", function() {
          const provinciaValue = provinciaSelect.value;
      
          if (provinciaValue !== "def") {
            localidadSelect.disabled = false;
            localidadSelect.classList.remove("bg-zinc-400");
            localidadSelect.classList.remove("text-zinc-600");
            localidadSelect.classList.add("bg-zinc-300");
            localidadSelect.classList.add("text-zinc-800");
      
            localidadSelect.innerHTML = '<option value="def">Escribí o selecciona tu localidad</option>';
      
            const localidades = datosProvincias[provinciaValue].localidades;
      
            localidades.forEach(function(localidad) {
              const option = document.createElement("option");
              option.value = localidad;
              option.text = localidad;
              localidadSelect.appendChild(option);
            });
      
            localidadSelect.value = "def";
            sedesSelect.value = "def";
            sedesSelect.disabled = true;
            sedesSelect.classList.remove("bg-zinc-300");
            sedesSelect.classList.add("bg-zinc-400");
      
            sedesSelect.value = "def";
          } else {
            localidadSelect.disabled = true;
            localidadSelect.classList.remove("bg-zinc-300");
            localidadSelect.classList.remove("text-zinc-800");
            localidadSelect.classList.add("bg-zinc-400");
            localidadSelect.classList.add("text-zinc-600");
      
            localidadSelect.value = "def";
      
            sedesSelect.disabled = true;
            sedesSelect.classList.remove("bg-zinc-300");
            sedesSelect.classList.add("bg-zinc-400");
      
            sedesSelect.value = "def";
          }
        });
      
        localidadSelect.addEventListener("change", function() {
          const localidadValue = localidadSelect.value;
      
          if (localidadValue !== "def") {
            sedesSelect.disabled = false;
            sedesSelect.classList.remove("bg-zinc-400");
            sedesSelect.classList.remove("text-zinc-600");
            sedesSelect.classList.add("bg-zinc-300");
            sedesSelect.classList.add("text-zinc-800");
      
            sedesSelect.innerHTML = '<option value="def">Selecciona tu sede</option>';
      
            const sedes = datosProvincias[provinciaSelect.value].sedes;
      
            sedes.forEach(function(sede) {
              const option = document.createElement("option");
              option.value = sede;
              option.text = sede;
              sedesSelect.appendChild(option);
            });
      
            sedesSelect.value = "def";
          } else {
            sedesSelect.disabled = true;
            sedesSelect.classList.remove("bg-zinc-400");
            sedesSelect.classList.remove("text-zinc-800");
            sedesSelect.classList.add("bg-zinc-400");
            sedesSelect.classList.remove("text-zinc-600");

            sedesSelect.value = "def";
          }
        });

        function validarDatos() {
            const provinciaSelect = document.getElementById("provincia");
            const localidadSelect = document.getElementById("localidad");
            const sedesSelect = document.getElementById("sedes");
            if (provinciaSelect.value !== "def" && localidadSelect.value !== "def" && sedesSelect.value !== "def") {
                    window.location.href = "elegirFecha.html";
                } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Formulario Incompleto',
                    text: 'Revisa el formulario antes de continuar',
                    showCloseButton: true,
                    confirmButtonColor: '#348214',
                    confirmButtonText: 'Continuar',
                    cancelButtonText: '<i class="fa fa-thumbs-down"></i>'
                })
            }
        }