var imagenes = [
    'bg-humahuaca',
    'bg-mate',
    'bg-plaza'
    ];

    var textos = [
    "Tu perfil digital ciudadano para gestionar trámites, sacar turnos, acceder a tus credenciales y recibir información personalizada.",
    "La Constancia de Cuil, el DNI digital, la Licencia de Nacional de Conducir, la Credencial de Trasplantado y la de Donación de Órganos disponibles en el teléfono.",
    "Accedé a todos tus turnos para realizar trámites. Cancelalos, reprogramalos o sacá nuevos."
    ];

    var titulos = [
    "Mi Argentina",
    "Perfil digital",
    "Gestión 100% online"
    ];

    
    var indiceImagenActual = 0;

    function cambiarImagen(indice) {
        var sliderContainer = document.querySelector('.slider-container');
        var titulo = document.getElementById('titulo');
        var descripcion = document.getElementById('descripcion');
        var slider1 = document.getElementById('slider1');
        var slider2 = document.getElementById('slider2');
        var slider3 = document.getElementById('slider3');
        sliderContainer.classList.remove('bg-humahuaca');
        sliderContainer.classList.remove('bg-mate');
        sliderContainer.classList.remove('bg-plaza');
        slider1.src = "img/icons/circle-stop-regular.svg";
        slider2.src = "img/icons/circle-stop-regular.svg";
        slider3.src = "img/icons/circle-stop-regular.svg";

        sliderContainer.classList.add(imagenes[indice])
        switch(indice){
            case 0:
                slider1.src = "img/icons/circle-stop-solid.svg";
                break;
            case 1:
                slider2.src = "img/icons/circle-stop-solid.svg";
                break;
            case 2:
                slider3.src = "img/icons/circle-stop-solid.svg";
                break;
        }

        titulo.textContent = titulos[indice];
        descripcion.textContent = textos[indice];
    }

    function anteriorImagen() {
    indiceImagenActual--;
    if (indiceImagenActual < 0) {
        indiceImagenActual = imagenes.length - 1;
    }
    console.log('anterior')
    cambiarImagen(indiceImagenActual);
    }

    function siguienteImagen() {
    indiceImagenActual++;
    if (indiceImagenActual >= imagenes.length) {
        indiceImagenActual = 0;
    }
    cambiarImagen(indiceImagenActual);
    }